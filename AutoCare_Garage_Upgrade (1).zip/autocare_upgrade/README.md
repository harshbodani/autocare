# AutoCare Garage — Flutter + PostgreSQL + Render

An upgraded vehicle workshop management app with a garage-inspired orange/charcoal UI, a shared sign-in screen, role-aware access, PostgreSQL persistence, and optional email/SMS notifications.

## Included
- Flutter client for web, Android, and desktop targets
- Node.js/Express REST API in `backend/`
- PostgreSQL schema in `backend/schema.sql`
- Render deployment blueprint in `backend/render.yaml`
- JWT sessions, bcrypt password hashing, request validation, and rate-limited login/register
- Admin sees all customers, vehicles, bookings, invoices, and reminders; normal users are scoped to the customer profile created for their account
- Optional SMTP email and Twilio SMS integrations configured with environment variables

## Deploy backend to Render
1. Push this project to a Git repository.
2. In Render, create a Blueprint from the repository and choose `backend/render.yaml`, or create a PostgreSQL database and Node web service manually.
3. Ensure the API service has `DATABASE_URL` set to the Render PostgreSQL **internal** connection string, plus a long random `JWT_SECRET`.
4. Apply `backend/schema.sql` to the database using Render's database shell or a PostgreSQL client. It creates the tables; it does not seed a public admin account.
5. Set SMTP/Twilio environment variables if you want actual email/SMS delivery. These services require provider credentials and verified sender/recipient setup.
6. Deploy the service and verify `https://YOUR-API.onrender.com/health` returns `{ "ok": true, ... }`.

## Configure Flutter to use the deployed API
Run from the project root:

```bash
flutter pub get
flutter run -d chrome --dart-define=API_BASE_URL=https://YOUR-API.onrender.com/api
```

For a release web build:

```bash
flutter build web --release --dart-define=API_BASE_URL=https://YOUR-API.onrender.com/api
```

For a mobile build, use the same `--dart-define` value. The default local URL is `http://localhost:10000/api` on web and `http://10.0.2.2:10000/api` on an Android emulator.

## Create the first admin safely
Public registration always creates a `USER`; users cannot select or promote their own role. After registering an account, promote it once using a trusted database connection:

```sql
UPDATE users SET role = 'ADMIN' WHERE email = 'your-admin-email@example.com';
```

Sign out and sign back in so the refreshed token carries the new role. Never expose database credentials or the admin promotion query in the client app.

## Email and SMS setup
Set these variables on the Render web service:

- Email: `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`, `EMAIL_FROM`
- SMS: `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM`

Registration attempts a welcome email when SMTP is configured. Admin-only notification endpoint: `POST /api/notifications/send` with a bearer token and JSON such as:

```json
{"email":"customer@example.com","phone":"+14155552671","subject":"Service reminder","message":"Your vehicle service is due soon."}
```

Only channels with a destination and valid provider configuration are sent. Provider credentials are server-side only.

## Important access-control note
Customer accounts see records connected to the customer profile created during registration. Admin-created customer records are not automatically linked to a login account; to enable a customer login for one of those records, link its `customers.user_id` to the matching user and set `users.customer_id` accordingly using a trusted admin workflow. Admin CRUD operations cover the whole workshop dataset.

## Local backend development
```bash
cd backend
cp .env.example .env
# Set DATABASE_URL and JWT_SECRET in .env
npm install
npm start
```

Apply `schema.sql` to your local PostgreSQL database before starting the API. Do not commit `.env` or provider secrets.
