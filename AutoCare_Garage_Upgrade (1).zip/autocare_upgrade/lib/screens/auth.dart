import 'package:flutter/material.dart';
import '../services/auth.dart';
import '../widgets/common.dart';
import 'dashboard.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  State<LoginScreen> createState() => _LoginState();
}

class _LoginState extends State<LoginScreen> {
  final e = TextEditingController(), p = TextEditingController();
  bool load = false;
  Future<void> go() async {
    setState(() => load = true);
    try {
      await AuthService.login(e.text, p.text);
      if (mounted)
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => const Dashboard()));
    } catch (x) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(x.toString())));
    }
    setState(() => load = false);
  }

  Widget build(BuildContext c) => Scaffold(
    backgroundColor: const Color(0xFF17212B),
    body: Center(child: SingleChildScrollView(child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 980),
      child: Padding(padding: const EdgeInsets.all(22), child: Container(
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.22), blurRadius: 32, offset: const Offset(0,14))]),
        child: LayoutBuilder(builder: (context, constraints) => Flex(
          mainAxisSize: MainAxisSize.min,
          direction: constraints.maxWidth > 650 ? Axis.horizontal : Axis.vertical,
          children: [
            Flexible(fit: FlexFit.loose, flex: constraints.maxWidth > 650 ? 5 : 1, child: Container(
              constraints: const BoxConstraints(minHeight: 390), padding: const EdgeInsets.all(32),
              decoration: const BoxDecoration(color: Color(0xFFE85D04), borderRadius: BorderRadius.only(topLeft: Radius.circular(18), bottomLeft: Radius.circular(18))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: const [
                Icon(Icons.car_repair, color: Colors.white, size: 54), SizedBox(height: 22),
                Text('AUTOCARE', style: TextStyle(color: Colors.white, fontSize: 31, fontWeight: FontWeight.w900, letterSpacing: 2)),
                Text('GARAGE MANAGEMENT', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2)),
                SizedBox(height: 22), Text('Every vehicle. Every service. One pit stop.', style: TextStyle(color: Colors.white, fontSize: 18, height: 1.4)),
                SizedBox(height: 18), Text('Bookings  •  Vehicle records  •  Service history  •  Invoices', style: TextStyle(color: Colors.white, height: 1.6)),
              ]),
            )),
            Flexible(fit: FlexFit.loose, flex: 5, child: Padding(padding: const EdgeInsets.all(30), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Welcome back', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: Color(0xFF17212B))),
              const SizedBox(height: 6), const Text('Sign in to your garage workspace.', style: TextStyle(color: Color(0xFF667085))),
              const SizedBox(height: 25), Field(controller: e, label: 'Email address'), Field(controller: p, label: 'Password', obscure: true),
              SizedBox(width: double.infinity, child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE85D04), padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))), onPressed: load ? null : go, icon: const Icon(Icons.login), label: Text(load ? 'Signing in...' : 'Sign in')),
              const SizedBox(height: 8), Center(child: TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignUpScreen())), child: const Text('New to AutoCare? Create an account'))),
              const SizedBox(height: 6), const Text('Your account role determines what you can access. Admin accounts are provisioned by the system administrator.', style: TextStyle(fontSize: 11, color: Color(0xFF667085))),
            ]))),
          ],
        )),
      )),
    ))),
  );
}

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});
  State<SignUpScreen> createState() => _SignState();
}

class _SignState extends State<SignUpScreen> {
  final n = TextEditingController(),
      e = TextEditingController(),
      p = TextEditingController();
  Future<void> go() async {
    try {
      await AuthService.register(n.text, e.text, p.text);
      if (mounted) Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Account created. Login now.')));
    } catch (x) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(x.toString())));
    }
  }

  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('Sign Up')),
      body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            Field(controller: n, label: 'Full Name'),
            Field(controller: e, label: 'Email'),
            Field(controller: p, label: 'Password', obscure: true),
            SizedBox(
                width: double.infinity,
                child: FilledButton(
                    onPressed: go, child: const Text('Create Account')))
          ])));
}
