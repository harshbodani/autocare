import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// PostgreSQL-backed AutoCare Garage REST API. Set API_BASE_URL at build time for deployment.
class ApiService {
  static String get baseUrl {
    const configured = String.fromEnvironment('API_BASE_URL');
    if (configured.isNotEmpty) return configured.replaceAll(RegExp(r'/$'), '');
    if (kIsWeb) return 'http://localhost:10000/api';
    return 'http://10.0.2.2:10000/api';
  }

  static Future<void> init() async {}

  static Future<String?> token() async => (await SharedPreferences.getInstance()).getString('token');

  static Future<Map<String, String>> _headers() async {
    final t = await token();
    return {
      'Content-Type': 'application/json',
      if (t != null) 'Authorization': 'Bearer $t',
    };
  }

  static Future<dynamic> get(String path) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl$path'), headers: await _headers());
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      throw Exception('Failed to load data: ${response.body}');
    } catch (e) {
      rethrow;
    }
  }

  static Future<dynamic> post(String path, Map body) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$path'),
        headers: await _headers(),
        body: jsonEncode(body),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        return jsonDecode(response.body);
      }
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'Failed to post data');
    } catch (e) {
      rethrow;
    }
  }

  static Future<dynamic> put(String path, Map body) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl$path'),
        headers: await _headers(),
        body: jsonEncode(body),
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'Failed to update data');
    } catch (e) {
      rethrow;
    }
  }

  static Future<dynamic> delete(String path) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl$path'),
        headers: await _headers(),
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'Failed to delete data');
    } catch (e) {
      rethrow;
    }
  }
}
