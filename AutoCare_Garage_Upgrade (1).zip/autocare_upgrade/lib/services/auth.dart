import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'api.dart';

/// PostgreSQL-backed authentication service for AutoCare.
class AuthService {
  static Future<void> login(String email, String password) async {
    if (email.trim().isEmpty || password.isEmpty) throw Exception('Enter your email and password.');
    try {
      final response = await http.post(
        Uri.parse('${ApiService.baseUrl}/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email.trim(), 'password': password}),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final p = await SharedPreferences.getInstance();
        await p.setString('token', data['token']);
        await p.setString('user', jsonEncode(data['user']));
        return;
      }
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'Invalid email or password.');
    } catch (e) {
      throw Exception(e.toString().replaceAll('Exception: ', ''));
    }
  }

  static Future<void> register(String name, String email, String password) async {
    if (name.trim().isEmpty || !email.contains('@') || password.length < 4) {
      throw Exception('Enter a name, valid email and password (at least 4 characters).');
    }
    try {
      final response = await http.post(
        Uri.parse('${ApiService.baseUrl}/auth/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'name': name.trim(), 'email': email.trim(), 'password': password}),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        return;
      }
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'Registration failed.');
    } catch (e) {
      throw Exception(e.toString().replaceAll('Exception: ', ''));
    }
  }

  static Future<void> logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('token');
    await p.remove('user');
  }

  static Future<bool> isLoggedIn() async => (await SharedPreferences.getInstance()).getString('token') != null;

  static Future<Map<String, dynamic>> user() async {
    final raw = (await SharedPreferences.getInstance()).getString('user');
    if (raw == null) return {'name': 'Admin User', 'email': 'admin@autocare.com', 'role': 'ADMIN'};
    return Map<String, dynamic>.from(jsonDecode(raw));
  }
}
